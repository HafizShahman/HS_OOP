package com.drawshape;

import java.util.Scanner;

interface Shape {

    public void draw();
    public  void getArea();

}

class Rectangle implements Shape{
    double TotalArea = 0;
    int Length,Height;
    @Override
    public void draw() {

        TotalArea = Length * Height;
    }

    @Override
    public void getArea() {

    }
}
class Circle implements Shape{
    double TotalArea = 0;
    int Length,Height;
    @Override
    public void draw() {

    }

    @Override
    public void getArea() {

    }
}
class Square implements Shape{
    double totalArea = 0;
    int Length;
    @Override
    public void draw() {

    }

    @Override
    public void getArea() {

    }
}
class DisShape {
    public static void main(String[] Args){
        Scanner scan = new Scanner(System.in);
        int length,height;

        System.out.println("Length : ");
        length = scan.nextInt();
        


    }
}


